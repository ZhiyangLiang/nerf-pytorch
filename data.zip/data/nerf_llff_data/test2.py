import os

folder_path = 'images'

# 获取当前目录下的所有png文件
png_files = [f for f in os.listdir(folder_path) if f.endswith('.png')]

# 对每个文件进行重命名
for i, filename in enumerate(sorted(png_files), 1):
    print(filename)
    # 构造新的文件名
    new_filename = f'image_{i:02d}.png'
    
    filename_path = os.path.join(folder_path, filename)
    new_filename_path = os.path.join(folder_path, new_filename)
    
    # 重命名文件
    os.rename(filename_path, new_filename_path)
    
    print(f'已将 {filename_path} 重命名为 {new_filename_path}')

print('所有PNG文件重命名完成。')
